<?php
/**
 * Default Lexicon Entries for ContextKeeper
 *
 * @package contextkeeper
 * @subpackage lexicon
 */
$_lang['contextkeeper'] = 'ContextKeeper';
