<?php
/**
 * @package contextkeeper
 * @subpackage plugin
 */

namespace TreehillStudio\ContextKeeper\Plugins\Events;

use modResource;
use TreehillStudio\ContextKeeper\Plugins\Plugin;
use xPDO;

class OnBeforeDocFormSave extends Plugin
{
    public function process()
    {
        /** @var modResource $resource */
        $resource = $this->modx->getOption('resource', $this->scriptProperties);
        $writableContexts = $this->contextkeeper->getOption('writableContexts');
        if (!in_array($resource->get('context_key'), $writableContexts)) {
            if (!empty($writableContexts)) {
                $message = 'The resource ' . $resource->get('id') . ' can’t be saved in the context "' . $resource->get('context_key') . '".';
                if ($this->contextkeeper->getOption('debug')) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnBeforeDocFormSave');
                }
            } else {
                if ($this->contextkeeper->getOption('checkEmpty')) {
                    $message = 'The writable_contexts system/usergroup/user setting is empty and the resource can’t be saved in the context "' . $resource->get('context_key') . '".';
                    if ($this->contextkeeper->getOption('debug')) {
                        $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnBeforeDocFormSave');
                    }
                    $this->modx->event->output($message);
                }
            }
        }
    }
}
