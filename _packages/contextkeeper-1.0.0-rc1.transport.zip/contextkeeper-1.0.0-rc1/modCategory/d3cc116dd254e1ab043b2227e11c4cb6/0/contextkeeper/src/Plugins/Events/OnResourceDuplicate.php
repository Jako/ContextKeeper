<?php
/**
 * @package contextkeeper
 * @subpackage plugin
 */

namespace TreehillStudio\ContextKeeper\Plugins\Events;

use modResource;
use TreehillStudio\ContextKeeper\Plugins\Plugin;
use xPDO;

class OnResourceDuplicate extends Plugin
{
    public function process()
    {
        /** @var modResource $newResource */
        $newResource = $this->modx->getOption('newResource', $this->scriptProperties);
        $writableContexts = $this->contextkeeper->getOption('writableContexts');
        if (!in_array($newResource->get('context_key'), $writableContexts)) {
            if (!empty($writableContexts)) {
                $newResource->set('context_key', reset($writableContexts));
                $newResource->set('parent', 0);
                $message = 'The duplicated resource ' . $newResource->get('id') . ' is moved to the writable context "' . $newResource->get('context_key') . '".';
                if ($this->contextkeeper->getOption('debug')) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnResourceDuplicate');
                }
            } else {
                if ($this->contextkeeper->getOption('checkEmpty')) {
                    $message = 'The writable_contexts user setting is empty and the resource can’t be moved to any context.';
                    if ($this->contextkeeper->getOption('debug')) {
                        $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnResourceDuplicate');
                    }
                    $newResource->remove();
                }
            }
        }
    }
}
