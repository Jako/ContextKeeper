<?php
/**
 * @package contextkeeper
 * @subpackage plugin
 */

namespace TreehillStudio\ContextKeeper\Plugins\Events;

use modResource;
use TreehillStudio\ContextKeeper\Plugins\Plugin;
use xPDO;

class OnBabelDuplicate extends Plugin
{
    public function process()
    {
        /** @var modResource $newResource */
        $duplicateResource = $this->modx->getOption('duplicate_resource', $this->scriptProperties);
        $writableContexts = $this->contextkeeper->getOption('writableContexts');
        if (!in_array($duplicateResource->get('context_key'), $writableContexts)) {
            if (!empty($writableContexts)) {
                $duplicateResource->set('context_key', reset($writableContexts));
                $duplicateResource->set('parent', 0);
                $message = 'The duplicated Babel resource ' . $duplicateResource->get('id') . ' is moved to the writable context "' . $duplicateResource->get('context_key') . '".';
                if ($this->contextkeeper->getOption('debug')) {
                    $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnBabelDuplicate');
                }
            } else {
                if ($this->contextkeeper->getOption('checkEmpty')) {
                    $message = 'The writable_contexts user setting is empty and the Babel resource can’t be moved to any context.';
                    if ($this->contextkeeper->getOption('debug')) {
                        $this->modx->log(xPDO::LOG_LEVEL_ERROR, $message, '', 'ContextKeeper OnBabelDuplicate');
                    }
                    $duplicateResource->remove();
                }
            }
        }
    }
}
