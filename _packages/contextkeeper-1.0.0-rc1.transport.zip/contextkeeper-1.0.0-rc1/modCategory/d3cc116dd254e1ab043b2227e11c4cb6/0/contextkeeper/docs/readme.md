# ContextKeeper

Avoid saving resources in the wrong context.

- Author: Thomas Jakobi <office@treehillstudio.com>
- License: GNU GPLv2

## Features

- 

## Installation

MODX Package Management

## Documentation

For more information please read the documentation on https://jako.github.io/contextkeeper/

## GitHub Repository

https://github.com/Jako/contextkeeper
